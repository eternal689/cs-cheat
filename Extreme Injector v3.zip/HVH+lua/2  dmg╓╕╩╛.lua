local rbot_ref = gui.Reference("Ragebot")
local rbot_tab = gui.Tab(rbot_ref, "min_dmg_override", "Min Damage Override")
local min_dmg_box = gui.Groupbox(rbot_tab, "Minimum Damage Override", 15, 15, 292.5, 250)

local min_dmg_override_check = gui.Checkbox(min_dmg_box, "min_dmg", "Master Switch", false)
local min_dmg_override_ind_check = gui.Checkbox(min_dmg_box, "min_dmg_ind", "Indicator", false)
local min_dmg_override_ind_color_p = gui.ColorPicker(min_dmg_override_ind_check, "min_dmg_ind_color", "ColorPicker", 255, 255, 255)
local min_dmg_override_toggle_keyb = gui.Keybox(min_dmg_box, "min_dmg_keyb", "Min Damage Override Toggle", 0)
local override_dmg_awp_slid = gui.Slider(min_dmg_box, "ov_dmg_awp", "Override AWP Min Damage", 1, 0, 130)
local original_dmg_awp_slid = gui.Slider(min_dmg_box, "or_dmg_awp", "Original AWP Min Damage", (gui.GetValue("rbot.hitscan.accuracy.sniper.mindamage")), 0, 130)
local override_dmg_scout_slid = gui.Slider(min_dmg_box, "ov_dmg_scout", "Override Scout Min Damage", 1, 0, 130)
local original_dmg_scout_slid = gui.Slider(min_dmg_box, "or_dmg_scout", "Original Scout Min Damage", (gui.GetValue("rbot.hitscan.accuracy.scout.mindamage")), 0, 130)
local override_dmg_r8_slid = gui.Slider(min_dmg_box, "ov_dmg_r8", "Override Heavy Pistol Min Damage", 1, 0, 130)
local original_dmg_r8_slid = gui.Slider(min_dmg_box, "or_dmg_r8", "Original Heavy Pistol Min Damage", (gui.GetValue("rbot.hitscan.accuracy.hpistol.mindamage")), 0, 130)
local override_dmg_auto_slid = gui.Slider(min_dmg_box, "ov_dmg_auto", "Override Auto Min Damage", 1, 0, 130)
local original_dmg_auto_slid = gui.Slider(min_dmg_box, "or_dmg_auto", "Original Auto Min Damage", (gui.GetValue("rbot.hitscan.accuracy.asniper.mindamage")), 0, 130)
local override_dmg_pistol_slid = gui.Slider(min_dmg_box, "ov_dmg_pistol", "Override Pistol Min Damage", 1, 0, 130)
local original_dmg_pistol_slid = gui.Slider(min_dmg_box, "or_dmg_pistol", "Original Pistol Min Damage", (gui.GetValue("rbot.hitscan.accuracy.pistol.mindamage")), 0, 130)

min_dmg_override_check:SetDescription("Enable Minimum Damage Override.")
min_dmg_override_ind_check:SetDescription("Draw Indicator showing your current Min DMG.")

local original_dmg =
{
    original_dmg_awp_slid;
    original_dmg_scout_slid;
    original_dmg_r8_slid;
    original_dmg_auto_slid;
    original_dmg_pistol_slid;
}

local override_dmg =
{
    override_dmg_awp_slid;
    override_dmg_scout_slid;
    override_dmg_r8_slid;
    override_dmg_auto_slid;
    override_dmg_pistol_slid;
}

local weapons =
{
    "sniper";
    "scout";
    "hpistol";
    "asniper";
    "pistol";
    "knife";
    "smg";
    "rifle";
    "shotgun";
    "lmg";
    "shared";
}

local font_1 = draw.CreateFont("Verdana", 12)
local run_funcs = false
local min_dmg_override_toggled = false
local screen_w, screen_h = 0, 0
local screen_w_h, screen_h_h = 0, 0
local min_dmg_state = original_dmg
local lp
local lp_active_weapon

local function condition_handler()

    lp = entities.GetLocalPlayer()

    screen_w, screen_h = draw.GetScreenSize()
    screen_w_h = screen_w * 0.5
    screen_h_h = screen_h * 0.5

    if lp ~= nil and lp:IsAlive() then

        lp_active_weapon = lp:GetPropEntity("m_hActiveWeapon")
        run_funcs = true
    else
        run_funcs = false
    end
end

callbacks.Register("Draw", condition_handler)

local function curr_weapon()

    if run_funcs then

        local current_weapon_type = lp_active_weapon:GetWeaponType()
        local current_weapon_id = lp_active_weapon:GetWeaponID()

        if current_weapon_id == 9 then
            return weapons[1]
        elseif current_weapon_id == 40 then
            return weapons[2]
        elseif current_weapon_id == 1 or current_weapon_id == 64 then
            return weapons[3]
        elseif current_weapon_id == 11 or current_weapon_id == 38 then
            return weapons[4]
        elseif current_weapon_type == 1 then
            return weapons[5]
        elseif current_weapon_type == 0 then
            return weapons[6]
        elseif current_weapon_type == 2 then
            return weapons[7]
        elseif current_weapon_type == 3 then
            return weapons[8]
        elseif current_weapon_type == 4 then
            return weapons[9]
        elseif current_weapon_type == 6 then
            return weapons[10]
        else
            return weapons[11]
        end
    end
end

local function min_dmg_override()

    for i = 1, #original_dmg do
        if min_dmg_override_toggled then
            original_dmg[i]:SetInvisible(true)
            override_dmg[i]:SetInvisible(false)
        else
            original_dmg[i]:SetInvisible(false)
            override_dmg[i]:SetInvisible(true)
        end
    end

    if min_dmg_override_check:GetValue() and min_dmg_override_toggle_keyb:GetValue() ~= 0 then
        if input.IsButtonPressed(min_dmg_override_toggle_keyb:GetValue()) then

            min_dmg_override_toggled = not min_dmg_override_toggled

            if not min_dmg_override_toggled then
                min_dmg_state = original_dmg
            else
                min_dmg_state = override_dmg
            end

            for i = 1, 5 do
                gui.SetValue("rbot.hitscan.accuracy." .. weapons[i] .. ".mindamage", min_dmg_state[i]:GetValue())
            end
        end
    end
end
callbacks.Register("Draw", min_dmg_override)

local function draw_min_dmg()

    if run_funcs then
        if min_dmg_override_ind_check:GetValue() then
            if curr_weapon() ~= "knife" then
            local min_dmg = gui.GetValue("rbot.hitscan.accuracy." .. curr_weapon() .. ".mindamage")
            draw.Color(min_dmg_override_ind_color_p:GetValue())
            draw.SetFont(font_1)
            draw.TextShadow((screen_w_h + 5), (screen_h / 2 - 15), tostring(min_dmg))
            end
        end
    end
end
callbacks.Register("Draw", draw_min_dmg)