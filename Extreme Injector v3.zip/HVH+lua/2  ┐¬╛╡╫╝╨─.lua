--BY  JONER
local MENU = gui.Reference("Visuals","Other");
local GBOX = gui.Groupbox(MENU, "开镜准心", 328,410,296,0);
local checkboxenable = gui.Checkbox(GBOX,"scope_crosshair.enable", "开启" , true);
local colorui = gui.ColorPicker(GBOX,"scope_crosshair.clr", "颜色" ,255, 255,255,255);
local jiangeui = gui.Slider(GBOX, "scope_crosshair.jiange", "间隔", 1, 0, 100,0.1);
local longui = gui.Slider(GBOX, "scope_crosshair.dlong", "默认长度", 1, 0, 100,1);
local slongui = gui.Slider(GBOX, "scope_crosshair.slong", "开镜长度", 10, 0, 150,2);
local wideui = gui.Slider(GBOX, "scope_crosshair.wide", "宽度", 0.3, 0.2, 3,0.1);
local x,y = draw.GetScreenSize()
local jb = 0
local function drawmain()
   enbl = checkboxenable:GetValue();
   jiange = jiangeui:GetValue();
   wide = wideui:GetValue();
   long = longui:GetValue();
   slong = slongui:GetValue();
   clr1,clr2,clr3,clr4 = colorui:GetValue();
   LocalPlayer = entities.GetLocalPlayer();
   is_scope = LocalPlayer:GetPropBool("m_bIsScoped");
   if is_scope and enbl then
         local scoped = LocalPlayer:SetPropBool(false, "m_bIsScoped")
   end
  gradientW(x/2-jiange-jb-long,y/2-wide,x/2-jiange, y/2+wide,{ clr1,clr2,clr3,clr4 }, true)
  gradientH(x/2-wide,y/2-jiange-jb-long,x/2+wide, y/2-jiange,{ clr1,clr2,clr3,clr4}, true)
  gradientW(x/2+jiange,y/2-wide,x/2+jiange+jb+long, y/2+wide,{ clr1,clr2,clr3,clr4 }, false)
  gradientH(x/2-wide,y/2+jiange,x/2+wide, y/2+jiange+jb+long,{ clr1,clr2,clr3,clr4}, false)           
 if is_scope then
        ay = slong
 else
        ay = 0
 end

if ay ~= jb then
  if ay < jb then
jb = jb - 5
  else
jb = jb + 5
  end
end
end
client.SetConVar("weapon_debug_spread_show", 1, true); 
client.SetConVar("weapon_debug_spread_gap", 5, true);
callbacks.Register("Draw", function ()
    drawmain()
end)
callbacks.Register( "Draw", function ()
    client.SetConVar("fov_cs_debug", 90, true);
end)

function gradientW(x1, y1, x2, y2,col1, left)
    local w = x2 - x1
    local h = y2 - y1
    for i = 0, w do
        local a = i / w * 300
        local r, g, b = col1[1], col1[2], col1[3];
        draw.Color(r,g,b, a)
        if left then
            draw.FilledRect(x1 + i, y1, x1 + i + 1, y1 + h)
        else
            draw.FilledRect(x1 + w - i, y1, x1 + w - i + 1, y1 + h)
        end
    end
end
function gradientH( x, y, w1, h1, col1,down )
    local w = w1 - x
    local h = h1 - y
    for i = 0, h do
        local a = i / h * 300
        local r, g, b = col1[1], col1[2], col1[3];
        draw.Color(r,g,b, a)
        if down then
            draw.FilledRect( x, y+ i, x + w, y+ i+1 );
        else
            draw.FilledRect( x, y+h- i, x + w, y+h- i+1 );
        end
    end
end


